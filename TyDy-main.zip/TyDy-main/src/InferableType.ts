// InferableType.ts
  export enum InferableType {
    Null,
    Boolean,
    Number,
    String,
    Object,
    Array,
    Unknown,
    NestedObject,
    NestedArray,
  }