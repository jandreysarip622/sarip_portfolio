// ./src/TypeConstraint.ts

/**
 * Represents a type constraint.
 */
export type TypeConstraint = Record<string, any>;
